package entity;

import javax.swing.*;

import java.awt.Color;
import java.awt.event.*;

public class Slot {
	private boolean hasScooter;
	private boolean isLocked;
	private JLabel light;
	private JButton button;
	boolean success;//�Ƿ�ɹ���������actionPerform����Ϊtrue
	
	public Slot(boolean hasScooter,int index) {
		this.hasScooter = hasScooter;
		this.isLocked = true;
		this.light = new JLabel();
		this.button = new JButton(""+index);
		light.setOpaque(true);
		light.setBackground(Color.WHITE);
	}
	
	public boolean isHasScooter() {
		return hasScooter;
	}
	public void setHasScooter(boolean hasScooter) {
		this.hasScooter = hasScooter;
	}
	public boolean isLocked() {
		return isLocked;
	}
	public void setLocked(boolean isLocked) {
		this.isLocked = isLocked;
	}
}
