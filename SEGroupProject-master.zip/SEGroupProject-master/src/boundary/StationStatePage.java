package boundary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;

import control.StationControl;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class StationStatePage extends JFrame {

	private JPanel contentPane;
	private JButton btnFlash;
	private JButton btnBack;

	/**
	 * Create the frame.
	 * 
	 * @param managementPage
	 */
	public StationStatePage(ManagementSys managementPage) {
		setVisible(true);
		setTitle("Station State");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 500, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		String[] rowNames = { "Station", "A", "B", "C" };
		String[] columnNames = { "Total Scooters", "Available Scooters", "Currently in Use" };
//		String[][] rowData = { { "8", "8", "0" }, { "8", "8", "0" }, { "8", "8", "0" } };
		int[][] rowData = { { 8, 8, 0 }, { 8, 8, 0 }, { 8, 8, 0 } };

		JLabel raw[][] = new JLabel[4][1];
		for (int i = 0; i < 4; i++) {
			raw[i][0] = new JLabel(rowNames[i]);
			raw[i][0].setBounds(10, 20 + i * 15, 60, 15);
			raw[i][0].setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			contentPane.add(raw[i][0]);
		}
		JLabel column[] = new JLabel[3];
		for (int i = 0; i < 3; i++) {
			column[i] = new JLabel(columnNames[i]);
			column[i].setBounds(70 + i * 125, 20, 125, 15);
			column[i].setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			contentPane.add(column[i]);
		}

		JLabel data[][] = new JLabel[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				data[i][j] = new JLabel(String.valueOf(rowData[i][j]));
				data[i][j].setBounds(70 + j * 125, 35 + i * 15, 125, 15);
				data[i][j].setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
				contentPane.add(data[i][j]);
			}
		}

		btnFlash = new JButton("Flash");
		btnFlash.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < 3; i++) {
					rowData[i][1] = StationControl.scooterNumberInStation(i);
					rowData[i][2] = 8 - StationControl.scooterNumberInStation(i);
					data[i][1].setText(String.valueOf(rowData[i][1]));
					data[i][2].setText(String.valueOf(rowData[i][2]));
				}
			}
		});
		btnFlash.setBounds(147, 186, 120, 40);
		contentPane.add(btnFlash);

		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				managementPage.setVisible(true);
			}
		});
		btnBack.setBounds(294, 186, 120, 40);
		contentPane.add(btnBack);

	}
}
